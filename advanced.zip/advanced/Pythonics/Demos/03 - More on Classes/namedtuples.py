tup = ('hello', object(), 42)



from collections import namedtuple
Widget = namedtuple('Widget','colour size')

w = Widget('blue', 1234)
print(repr(w))

w = Widget('red', 54)
print(w.colour)
print(w.size)

w = Widget('yellow', 87)
print(w[0])
print(w[1])


def display_widget(colour, size):
    print(colour)
    print(size)

w = Widget('purple', 21)
display_widget(*w)

w = Widget('yellow', 87)

class FooableWidget(Widget):
    def foo(self):
        print (repr(self))

fw = FooableWidget('black', 47)
fw.foo()

w = Widget('yellow', 87)
for f in w._fields:
    print (f)

ElectricWidget = namedtuple('ElectricWidget', Widget._fields + ('charge',))
ew = ElectricWidget('white', 45, '240 volts')
print(repr(ew))

ElectricWidget = namedtuple('ElectricWidget', Widget._fields + ('charge',))
ew = ElectricWidget('white', 45, '240 volts')
print(ew._asdict())

import json
ElectricWidget = namedtuple('ElectricWidget', Widget._fields + ('charge',))
ew = ElectricWidget('white', 45, '240 volts')
print(json.dumps(ew._asdict()))


ElectricWidget = namedtuple('ElectricWidget', Widget._fields + ('charge',))
ew = ElectricWidget('white', 45, '240 volts')
print(repr(ew))
ew2 = ew._replace(colour='blue')
print(repr(ew2))

ew3 = ElectricWidget._make(['cyan', 45432, '115 volts'])
print(ew3)

