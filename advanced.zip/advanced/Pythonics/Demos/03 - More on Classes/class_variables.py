class Account:
    next_id = 1000 # <- Class variable
    def __init__(self, name):
        self.name = name
        self.id = self.__class__.next_id
        self.__class__.next_id += 1

acc1 = Account('Jack')

print(acc1.id)
print(acc1.name)

print(acc1.next_id)
print(Account.next_id)

acc2 = Account('Jill')
Account.next_id = 88888
print(acc1.next_id)
print(acc2.next_id)
print(Account.next_id)


acc1.next_id = 99999
print(acc1.next_id)
print(acc2.next_id)
print(Account.next_id)

class CountedObject:
    num_instances = 0
    def __init__(self):
        self.__class__.num_instances += 1

print ( CountedObject.num_instances )
print ( CountedObject().num_instances )
print ( CountedObject().num_instances )
print ( CountedObject().num_instances )
print ( CountedObject.num_instances )

class BuggyCountedObject:
    num_instances = 0
    def __init__(self):
        self.num_instances += 1

print ( BuggyCountedObject.num_instances )
print ( BuggyCountedObject().num_instances )
print ( BuggyCountedObject().num_instances )
print ( BuggyCountedObject().num_instances )
print ( BuggyCountedObject.num_instances )
