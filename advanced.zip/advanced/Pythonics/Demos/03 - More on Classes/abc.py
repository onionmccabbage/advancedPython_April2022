class Gadget:
    def foo(self):
        raise NotImplementedError()

    def bar(self):
        raise NotImplementedError()

class Widget(Gadget):
    def foo(self):
        print ( 'foo() called')


g = Gadget()
#print(g.foo())

w = Widget()
w.foo()
#w.bar()


from abc import ABCMeta, abstractmethod
class Gadget(metaclass=ABCMeta):
    @abstractmethod
    def foo(self):
        pass

    @abstractmethod
    def bar(self):
        pass

class Widget(Gadget):
    def foo(self):
        pass

print(issubclass(Widget, Gadget))

w = Widget()

