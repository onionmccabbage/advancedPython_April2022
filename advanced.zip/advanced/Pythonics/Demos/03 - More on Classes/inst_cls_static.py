class Instrument:
    def method(self):
        print (f'instance method called', self)

    @classmethod
    def classmethod(cls):
        print (f'class method called', cls)

    @staticmethod
    def staticmethod():
        print ('static method called')

obj = Instrument()
#obj.method()
#Instrument.method(obj)

#Instrument.classmethod()

#obj.staticmethod()

#Instrument.classmethod()
#Instrument.staticmethod()
Instrument.method()

