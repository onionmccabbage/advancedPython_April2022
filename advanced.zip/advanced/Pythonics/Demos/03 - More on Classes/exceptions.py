def validate_pwd(pwd):
    if len(pwd) < 10:
        raise ValueError

#validate_pwd("password")

class PwdTooShortError(ValueError):
    pass

def validate_pwd2(pwd):
    if len(pwd) < 10:
        raise PwdTooShortError(pwd)



class BaseValidationError(ValueError):
    pass

class PwdTooShortError(BaseValidationError):
    pass

class PwdTooLongError(BaseValidationError):
    pass

class PwdTooSimpleError(BaseValidationError):
    pass

def handle_pwd_validation_exception(err):
    msg = f'Password Validation Exception: {str(err)}'
    print(msg)

def validate_pwd3(pwd):
    if len(pwd) < 8:
        raise PwdTooShortError(f'{str(pwd)} too short')
    elif len(pwd) > 16:
        raise PwdTooLongError(f'{str(pwd)} too long')
    elif pwd=='password':
        raise PwdTooSimpleError(f'{str(pwd)} too simple')

try:
    validate_pwd3("password")
except BaseValidationError as err:
    handle_pwd_validation_exception(err)
