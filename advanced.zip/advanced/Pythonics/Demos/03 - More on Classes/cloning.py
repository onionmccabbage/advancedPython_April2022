list1 = [1,2,3,4,5]
dict1 = {1:'A',2:'B',3:'C',4:'D',5:'E'}
set1 = {'A','B','C', 'D', 'E'}
new_list = list(list1)
new_dict = dict(dict1)
new_set = set(set1)

print(repr(list1))
print(repr(new_list))
list1[3] = 42
print(repr(list1))
print(repr(new_list))

l1 = [1,2,3,4,5]
l2 = l1
l1[3] = 42
print(l1)
print(l2)

xs = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
ys = list(xs)
xs.append([10, 11, 12])
print(xs)
print(ys)

xs[1][0] = 'X'
print(xs)
print(ys)

import copy
xs = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
ys = copy.deepcopy(xs)
xs.append([10, 11, 12])
print(xs)
print(ys)

xs[1][0] = 'X'
print(xs)
print(ys)

class Widget:
    def __init__(self, colour, size):
        self.colour = colour
        self.size = size

    def __repr__(self):
        return f'Widget({self.colour!r}, {self.size!r})'

w1 = Widget('blue', 42)
w2 = copy.copy(w1)
print(w1 is w2)

class Gadget:
    def __init__(self, a, b):
        self.alpha = a
        self.beta = b
    def __repr__(self):
        return (f'Gadget({self.alpha!r}, '
                f'{self.beta!r})')

g1 = Gadget(w1,w1)
g2 = copy.copy(g1)
print(g1)
print(g2)

g1.alpha.colour = 'Red'
print(g1)
print(g2)

w1 = Widget('blue', 42)
w2 = copy.deepcopy(w1)
g1 = Gadget(w1,w2)
g2 = copy.deepcopy(g1)
print(g1)
print(g2)

g1.alpha.colour = 'Red'
print(g1)
print(g2)



