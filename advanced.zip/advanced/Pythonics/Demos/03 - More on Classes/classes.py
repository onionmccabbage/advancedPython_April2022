class Person1:
    def __init__(self, name, age):
        self.name = name
        self.age = age

p = Person1('John', 23)
print(p)

print(p.name, p.age)


class Person2:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def __str__(self):
        return f'name {self.name} age {self.age}'

p = Person2('John', 23)
print(p)
s = str(p)
print(s)
s = '{}'.format(p)
print(s)

class Person3:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def __str__(self):
        return f'__str__ :: name {self.name} age {self.age}'

    def __repr__(self):
        return f'__repr__ :: name {self.name} age {self.age}'

p = Person3('John', 23)
print(p)

import datetime
now = datetime.date.today()
print (str(now))
print(repr(now))

class Widget:
    def __init__(self, colour, size):
        self.colour = colour
        self.size = size

    def __repr__(self):
        return f'Widget({self.colour!r}, {self.size!r})'

class Gadget:
    def __init__(self, colour, size):
        self.colour = colour
        self.size = size

    def __repr__(self):
        return (f'{self.__class__.__name__}('
                f'{self.colour!r}, {self.size!r})')


    def __str__(self):
        return f'a {self.colour} {self.size } Gadget'

w = Widget('widdy', 123)
g = Gadget('giddy', 456)
print(repr(w))
print(repr(g))
print(str(g))

class Glyph:
    def __init__(self, colour, size):
        self.colour = colour
        self.size = size

    def __repr__(self):
        return '{}({!r}, {!r})'.format(
            self.__class__.__name__,
            self.colour, self.size)
    
    def __unicode__(self):
        return u'a {self.colour} {self.size} Glpyh'.format(self=self)

    def __str__(self):
        return unicode(self).encode('utf-8')
