
# C- Style string formatting
fav_song = "Hey Jude"
s = 'Favourite song is %s' % fav_song
print(s)

fname = "Bob"
lname = "Dylan"
s = 'Favourite singer is %s %s' % (fname, lname)
print(s)


# New Style String Formatting
fav_song = "Hey Jude"
s = 'Favourite song is {}'.format(fav_song)
print(s)

fname = "Bob"
lname = "Dylan"
s = 'Favourite singer is {} {}'.format(fname, lname)
print(s)

s = 'Favourite singer is {s1} {s2}'.format(s1=fname, s2=lname)
print(s)

# Formatted String Literals
fav_song = "Hey Jude"
s = f'Favourite song is, {fav_song}!'
print(s)

a = 5
b = 10
s = f'Five plus ten is {a + b} and not {2 * (a + b)}.'
print(s)


# Template Strings
from string import Template
t = Template('Favourite singer is $s1 $s2')
s = t.substitute(s1=fname, s2=lname)
print(s)

# Security Problem
SENSITVE_DATA = 'Secret Information'
class Error:
    def __init__(self):
        pass
err = Error()

# Imagine a user enters the string '{error.__init__.__globals__[SENSITVE_DATA]}'
user_input = '{error.__init__.__globals__[SENSITVE_DATA]}'
# Display the input back to the user
s = user_input.format(error=err)
print (s)

user_input = '${error.__init__.__globals__[SECRET]}'
s = Template(user_input).substitute(error=err)
print(s)





