def foo(p1,p2):
    assert p1 > p2, "p2 gt than p1"
    



foo(42, 56)

