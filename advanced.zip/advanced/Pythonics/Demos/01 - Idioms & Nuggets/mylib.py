# mylib.py:
def external_func():
    return 23

def _internal_func():
    return 42