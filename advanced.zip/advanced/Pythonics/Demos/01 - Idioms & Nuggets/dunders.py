class Widget:
    def __init__(self):
        self.foo = 11
        self._bar = 23

w = Widget()
w.foo
w._bar


import mylib
mylib.external_func()

mylib._internal_func()

class Gadget:
    def __init__(self):
        self.foo = 'Base Class foo'
        self._bar = 'Base Class _bar'
        self.__baz = 'Base Class __baz'

g1 = Gadget()
#print(g1.foo)
#print(g1._bar)
#print(dir(g1))

class ExtendedGadget(Gadget):
    def __init__(self):
        super().__init__()
        self.foo = 'Overridden foo'
        self._bar = 'Overridden _bar'
        self.__baz = 'Overridden __baz'

g2 = ExtendedGadget()
#print (g2.foo)
#print(g2._bar)
#print(dir(g2))


print(g1._Gadget__baz)
print(g2._Gadget__baz)
print(g2._ExtendedGadget__baz)


