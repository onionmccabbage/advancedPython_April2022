widget = {
    'colour': 'red',
    'price': 3812.4,
    'single user': True
}

# Can read from
m = widget['price']

# Can update
widget['price'] = 12

# Can add new attributes to a dict
widget['expiry'] = 'Jan'

# Can incorrectly name attributes
widget = {
    'calar': 'red',
    'price': 3812.4,
    'single user': True
}

widget1 = ('red', 3812.4, True)

# Can read
widget1[1]

# NO protection for getting things in wrong order
#or wrong type
widget2 = ('blue', 25000, 'red', False, 123.45)


class Widget:
    def __init__(self, color, price, single):
        self.color = color
        self.price = price
        self.single = single

from collections import namedtuple
Gadget = namedtuple('Gadget' , 'colour price automatic')
g1 = Gadget('red', 3812.4, True)

# Can Read
g1.colour

#g1.price = 99.95

#g1.dimensions

from typing import NamedTuple

class Gpyph(NamedTuple):
    color: str
    mileage: float
    automatic: bool

gl1 = Gpyph('red', 3812.4, True)

# Instances have a nice repr:
print(g1)

# Can read
x = gl1.mileage

# Cannot change fields
#gl1.mileage = 12

# Cannot add new fields
#gl1.country = 'UK'

# Type annotations are not enforced without
# a separate type checking tool like mypy:
gl2 = Gpyph('red', 'NOT_A_FLOAT', 99)
gl3 = Gpyph(color='red', mileage='NOT_A_FLOAT', automatic=99)


from struct import Struct
MyStruct = Struct('i?f')
data = MyStruct.pack(23, False, 42.0)
print(data)
y = MyStruct.unpack(data)
print(y)


from types import SimpleNamespace
gadget1 = SimpleNamespace(color='red',price=3812.4,single=True)

print(gadget1)
gadget1.mileage = 12
print(gadget1)
gadget1.windshield = 'broken'
print(gadget1)
del gadget1.price
print(gadget1)
