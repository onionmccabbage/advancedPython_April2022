vowels = {'a', 'e', 'i', 'o', 'u'}

# Test for membership
'e' in vowels

# Use a set constructor
letters = set('alice')

#Test for intersection
letters.intersection(vowels)

# add an item to a set
vowels.add('x')

# How many items
len(vowels)

for l in letters:
    print(l)


# Use a set constructor
greeks = frozenset('DGRTV')

from collections import Counter
assets = Counter()

stocks = {'IBM': 1000, 'SNY': 50}
assets.update(stocks)
print(assets)

more_stocks = {'IBM': 5000, 'SNY': 150}
assets.update(more_stocks)
print(assets)


from collections import deque
s = deque()
s.append('home')
s.append('shower')
s.append('pub')
s.pop()
s.pop()
print(s)


from queue import LifoQueue
s = LifoQueue()
s.put('home')
s.put('shower')
s.put('pub')
s.get()
s.get()
s.get()
#s.get_nowait()

from collections import deque
s = deque()
s.append('home')
s.append('shower')
s.append('pub')
s.popleft()
print(s)


from queue import Queue
q = Queue()
q.put('home')
q.put('shower')
q.put('pub')
q.get()
q.get()
q.get()
#q.get_nowait()
#q.get()

from queue import PriorityQueue
q = PriorityQueue()
q.put((2, 'code'))
q.put((1, 'eat'))
q.put((3, 'sleep'))
while not q.empty():
    next_item = q.get()
    print(next_item)
