x = 'ABC'
print(x.__hash__())

y = ('A','B','C')
print(y.__hash__())

employees = {
    'bob': 7387,
    'alice': 3719,
    'jack': 7052,
}

cubes = {x: x * x *x for x in range(6)}

print(employees)
print(cubes)

import collections
a = collections.OrderedDict(three = 3, two=2, one = 1)
print(a)

a['four'] = 4
print(a)
print(a.keys())


from collections import defaultdict
band = defaultdict(list)
print(band['beatles'])

band['beatles'].append('John')
band['beatles'].append('Paul')
band['beatles'].append('George')
band['beatles'].append('Ringo')
print(band['beatles'])

from collections import ChainMap

dict1 = {'I': 1, 'II': 2}
dict2 = {'III': 3, 'IV': 4}
chain = ChainMap(dict1, dict2)
print(chain)
print(chain['III'])
chain['V'] = 5
print(chain)
print(dict1)
print(dict2)


from types import MappingProxyType
read_write = {'A': 70, 'B': 55}
read_only = MappingProxyType(read_write)
print(read_only)
print(read_write)


#read_only['A'] = 75
#read_only['C'] = 45
#del read_only['B']


