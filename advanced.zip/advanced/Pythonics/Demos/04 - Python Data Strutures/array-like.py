grades = ['A', 'B', 'C']
print(str(grades))

grades.append('d')
grades[3] = 'D'
del grades[1]

grades = ('A', 'B', 'C')
print(str(grades))



import array
print(array.typecodes)


array('l')
array('u', 'hello')
array('l', [1, 2, 3, 4, 5])
array('d', [1.0, 2.0, 3.14])