def foo(x,y,z):
    print('<%s, %s, %s>' % (x, y, z))


foo(1,2,3)

# Unpack a list
foo(*[1,2,3])

# Unpack a tuple
foo(*(1,2,3))

# Unpack a set
foo(*{1,2,3})

# Unpack a generator
genexpr = (x * x for x in range(3))
foo(*genexpr)


dict_vec = {'y': 0, 'z': 1, 'x': 1}
foo(*dict_vec)
foo(**dict_vec)

dict_vec = {'z': 1, 'y': 2, 'x': 3}
foo(*dict_vec)
foo(**dict_vec)