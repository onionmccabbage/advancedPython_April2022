add_lamba = lambda x, y: x + y
i = add_lamba(5, 3)
print(i)

def add_function(x, y):
    return x + y
j = add_function(5, 3)
print(j)

j = (lambda x, y: x + y)(5, 3)
print(j)


tups = [(1, 'Frazer'), (5, "Ali"), (2, 'Foreman'), (4, 'Holyfield'), (3, 'Tyson')]
data = sorted(tups, key=lambda x: x[1])
print(data)

data = [-3,-2,-1,0,1,2,3]
x = sorted(data, key=lambda x: x * x)
print(x)

def make_adder(n):
    return lambda x: x + n

plus_3 = make_adder(3)
plus_5 = make_adder(5)

x = plus_3(4)
y = plus_5(4)
print(x)
print(y)


x = list(filter(lambda x: x % 2 == 0, range(16)))
print(x)
y = [x for x in range(16) if x % 2 == 0]
print(y)