def foo1(value):
    if value:
        return value
    else:
        return None

def foo2(value):
    """Bare return statement implies `return None`"""
    if value:
        return value
    else:
        return

def foo3(value):
    """Missing return statement implies `return None`"""
    if value:
        return value

print(foo1('Hello'))
print(foo1(0))
print(foo2('Hello'))
print(foo2(0))
print(foo3('Hello'))
print(foo3(0))