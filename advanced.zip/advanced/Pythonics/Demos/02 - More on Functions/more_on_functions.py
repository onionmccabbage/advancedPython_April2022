def shout(text):
    return text.upper() + '!'

print(shout("loudly"))

bark = shout

print(bark("woof"))

del shout
#shout('help')

bark('grr')

print(bark.__name__)

funcs = [bark, str.lower, str.capitalize]
print(funcs)


for f in funcs:
    print(f, f('hello world'))

s = funcs[0]('growl')
print(s)

def greet(func):
    greeting = func('I am your father')
    print(greeting)

greet(bark)

def whisper(text):
    return text.lower() + '...'

greet(whisper)

orders = list(map(bark, ['attention', 'at ease', 'quick march']))
print (orders)

def speak(text):
    def whisper(t):
        return t.lower() + '...'

    return whisper(text)

s = speak("ARE YOU AWAKE")
print (s)

def get_speak_func(volume):
    def whisper(text):
        return text.lower() + '...'
    def yell(text):
        return text.upper() + '!'
    if volume > 0.5:
        return yell
    else:
        return whisper

greet = get_speak_func(0.2)
s = greet("we're gonna need a bigger boat")
print(s)

greet = get_speak_func(0.8)
s = greet("heres johnny")
print(s)

def get_speak_func_v2(text, volume):
    def whisper():
        return text.lower() + '...'

    def yell():
        return text.upper() + '!'

    if volume > 0.5:
        return yell
    else:
        return whisper

s = get_speak_func_v2('I AM YOUR FATHER', 0.2)()
print(s)
s = get_speak_func_v2('I AM YOUR FATHER', 0.8)()
print(s)


class Adder:
    def __init__(self, n):
        self.n = n
    def __call__(self, x):
        return self.n + x

plus_3 = Adder(3)
x = plus_3(4)
print(x)

print(callable(plus_3))
print(callable(bark))
print(callable('hello'))



