def show_message(msg):
    print(msg)
