.. include:: ../README.rst

Version: |version|

Methods
=======

.. toctree::
   :maxdepth: 2

   hello
   world


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
