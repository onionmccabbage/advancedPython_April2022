def show_message(msg):
    """Prints the given message to the screen

    :param msg: message to be printed
    """
    print(msg)
